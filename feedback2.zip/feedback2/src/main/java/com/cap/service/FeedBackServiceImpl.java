package com.cap.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cap.dao.FeedBackDao;
import com.cap.model.FeedBack;


@Service("FeedBackService")
@Transactional
public class FeedBackServiceImpl implements FeedBackService{

	@Autowired
	private FeedBackDao Feedbackdao;


	@Override
	public void save(FeedBack FeedBack) {
		Feedbackdao.save(FeedBack);
		
	}


	@Override
	public List<FeedBack> getAll() {
		return Feedbackdao.findAll();
	
	}


	@Override
	public  FeedBack getOne(Integer FeedBackId) {
		// TODO Auto-generated method stub
		return Feedbackdao.getOne(FeedBackId);
		 
	}


	
	
}
