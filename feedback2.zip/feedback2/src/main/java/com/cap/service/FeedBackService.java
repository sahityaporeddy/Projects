package com.cap.service;

import java.util.List;



import com.cap.model.FeedBack;



public interface FeedBackService {
	public void save(FeedBack FeedBack);
	public List<FeedBack> getAll();
	public FeedBack getOne(Integer FeedBackId);
	
}
