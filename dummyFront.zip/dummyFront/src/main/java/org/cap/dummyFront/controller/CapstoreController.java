package org.cap.dummyFront.controller;

import org.cap.dummyFront.model.Inventory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class CapstoreController {
	
	
	
	
	@RequestMapping("/Page1full")
	public String page1(ModelMap map) {

		final String uri="http://localhost:8085/DummyRestApp/api/v1/inventories";
		RestTemplate restTemplate=new RestTemplate();
		
		Inventory[] inventories= restTemplate.getForObject(uri, Inventory[].class);
		
		
		map.put("inventories",inventories);
		map.put("inventory", new Inventory());
		
		
		
		return "page1";
		
			
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
}
