package org.cap.dummyFront.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.cap.dummyFront.model.Inventory;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.client.RestTemplate;

@Controller
@SessionAttributes
public class CapstoreController {
	
	
	
	@RequestMapping("/")
	public String addProduct(ModelMap map) {
		
		final String uri="http://localhost:8084/RestInv/api/v2/products";
		RestTemplate restTemplate=new RestTemplate();
		
		Inventory[] inventories= restTemplate.getForObject(uri, Inventory[].class);
		
		
		map.put("inventories",inventories);
		map.put("inventory", new Inventory());
		return "adminaddProduct";
	}
	
	
	@RequestMapping("/addProducts")
	public String page(@Valid @ModelAttribute("inventory") Inventory inventory,
		BindingResult result) {
	if(!result.hasErrors()) {
		
		final String uri="http://localhost:8084/RestInv/api/v2/addProduct";
		RestTemplate restTemplate=new RestTemplate();
		
	//	ResponseEntity<Pilot> pilot1=
				restTemplate.postForEntity(uri,inventory,Inventory.class);
	
	}
	
	return "redirect:adminaddProduct";
		
	}
	
	 @RequestMapping("/admininventory/{productName}")
		public String getInventoryForm(@PathVariable ("productName") String productName, ModelMap map) {
		
			
			final String uri="http://localhost:8081/capstoreApp/api/v1/admininventory/{productName}";
			RestTemplate restTemplate=new RestTemplate();
			Map<String,Object> params=new HashMap<>();
			params.put("productName", productName);
			Inventory[] inventoryList= restTemplate.getForObject(uri, Inventory[].class,params);
			
			
			map.put("inventoryList",inventoryList);
			map.put("Inventory", new Inventory());
			
			return "adminInventoryManagement";
		}

	 
	 @RequestMapping("/updateProduct")
		public String updatePage()
		{
			return "updateproduct";
		}
		
		@RequestMapping("/remProduct")
		public String removePage()
		{
			return "remProduct";
		}
		
	
	
}
