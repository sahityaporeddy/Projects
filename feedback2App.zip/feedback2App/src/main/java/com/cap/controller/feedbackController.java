package com.cap.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.cap.model.FeedBack;



@Controller
public class feedbackController {
	
	@RequestMapping("/")
	public String feedbackForm(ModelMap map) {
		
		
		final String uri="http://localhost:8083/feedback2RestApp/api/v2/feedback";
		RestTemplate restTemplate=new RestTemplate();
		
		FeedBack[] fd= restTemplate.getForObject(uri, FeedBack[].class);
		
		
		map.put("fd",fd);
		map.put("feedback", new FeedBack());
		
		return "feedbackForm";
	}
		
		@RequestMapping("/saveComments")
		public String showFeedbackComment(
				@Valid @ModelAttribute("feedback") FeedBack feedback,@RequestParam("rati")String rati,
				BindingResult result) {
			if(!result.hasErrors()) {
				Integer rating=Integer.parseInt(rati);
				feedback.setProductRating(rating);
				final String uri="http://localhost:8083/feedback2RestApp/api/v2/feedback";
				RestTemplate restTemplate=new RestTemplate();
				

						restTemplate.postForEntity(uri,feedback,FeedBack.class);
			
			}
			
			return "feedbackForm";

}
}





