package com.cg.BackEndInven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndInvenApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndInvenApplication.class, args);
	}
}
