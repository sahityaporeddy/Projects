package com.cg.wallet.bean;

public class Transactions {
	private int accno;
	private String transactiontype;
	private double amount;
	private double balance;
	public int getAccno() {
		return accno;
	}
	public String getTransactiontype() {
		return transactiontype;
	}
	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String toString() {
		return "[Account number="+ accno + ", Transaction Type=" + transactiontype +", Amount=" +amount+ ", Balance=" + balance + "]";
	}
	

}
