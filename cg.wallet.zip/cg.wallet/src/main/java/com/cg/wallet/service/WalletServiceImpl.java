package com.cg.wallet.service;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Transactions;
import com.cg.wallet.bean.Wallet;
import com.cg.wallet.dao.WalletDao;
import com.cg.wallet.dao.WalletDaoImpl;
import com.cg.wallet.exception.WalletException;

public class WalletServiceImpl implements WalletService{

	WalletDao walletdao=new WalletDaoImpl();
	@Override
	public boolean validateWallet(Customer customer) throws WalletException {
		if(validateName(customer.getName()) && validatePhone(customer.getPhone())) {
			return true;
		}
		return false;
	}

	public boolean validateName(String name)throws WalletException
	{
		if(name.isEmpty()||name==null)
		{
			throw new WalletException("Customer name cannot be empty!");
		}
		else
		{
			if(!name.matches("[A-Z][A-Za-z]{2,}"))
			{
				throw new WalletException("Customer name shouls start with capital letter.");
			}
		}
		return true;
	}
	
	public boolean validatePhone(String phone) throws WalletException
	{
		if(phone.isEmpty()||phone==null)
		{
			throw new WalletException("Phone number cannot be empty!");
			
		}
		else
		{
			if(!phone.matches("\\d{10}"))
			{
				throw new WalletException("Phone number should be 10 digits!");
			}
		}
		return true;
	}
	

	@Override
	public int createAccount(Customer customer) throws WalletException {
		return walletdao.createAccount(customer);
	}

	@Override
	public double showBalance(int accno) throws WalletException {

		return walletdao.showBalance(accno);
	}

	@Override
	public double deposit(int accno, double amount) throws WalletException {

		return walletdao.deposit(accno,amount);
	}

	@Override
	public int withdraw(int accno, double amount) throws WalletException {
		
	 return walletdao.withdraw(accno,amount);
	}

	@Override
	public int fundTransfer(int faccno, int taccno, double amount) throws WalletException {
		
		return walletdao.fundTransfer(faccno,taccno,amount);
	}

	@Override
	public Transactions printTransactions(int accno) throws WalletException {
		return walletdao.printTransactions(accno);
	}

}
