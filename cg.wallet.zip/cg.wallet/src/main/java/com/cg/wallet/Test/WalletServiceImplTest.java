package com.cg.wallet.Test;

import com.cg.wallet.bean.Wallet;
import com.cg.wallet.dao.WalletDaoImpl;
import com.cg.wallet.exception.WalletException;
import com.cg.wallet.service.WalletServiceImpl;

import junit.framework.Assert;
import junit.framework.TestCase;

public class WalletServiceImplTest extends TestCase {
	
	public void testValidateName() throws WalletException {
		WalletServiceImpl w=new WalletServiceImpl();
		
		Assert.assertEquals(true, w.validateName("Sahi"));
		
	}

	public void testValidatePhone() throws WalletException {
		WalletServiceImpl w=new WalletServiceImpl();
		Assert.assertEquals(true, w.validatePhone("9789534069"));
		
	}

	public void testCreateAccount() {
		WalletDaoImpl w=new WalletDaoImpl();
		Wallet a=new Wallet();
		Assert.assertEquals(5001,  5001);
	}

	public void testValidateNamefail() {
		WalletServiceImpl c=new WalletServiceImpl();
		try {
			Assert.assertEquals(false, c.validateName("S@hi"));
		} catch (WalletException e) {
	}
	}
		public void testValidatePhonefail() {
			WalletServiceImpl w=new WalletServiceImpl();
			try {
				Assert.assertEquals(false, w.validatePhone("789654123123"));
			} catch (WalletException e) {
		}

}
	}
